//
//  EmailSignUpVC.swift
//  FormDemo
//
//  Created by Suraj Prasad on 05/04/19.
//  Copyright © 2019 Suraj Prasad. All rights reserved.
//

import UIKit
import CoreData
class EmailSignUpVC: UIViewController {
    //MARK:- IBOutlets
    @IBOutlet weak var signupEmail: UITextField!
    @IBOutlet weak var signupFirstName: UITextField!
    @IBOutlet weak var signupLastName: UITextField!
    @IBOutlet weak var signupPassword: UITextField!
    
    //MARK:- Global Variables
    var getEmail = ""
    var getFirstName = ""
    var getLastName = ""
    
    //MARK:- Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        fetchDataBase()
        signupEmail.text = getEmail
        signupFirstName.text = getFirstName
        signupLastName.text = getLastName
//        signupEmail.attributedPlaceholder = NSAttributedString(string:"Enter Email",
//                                                                                attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
//        signupFirstName.attributedPlaceholder = NSAttributedString(string:"First Name",
//                                                               attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
//        signupLastName.attributedPlaceholder = NSAttributedString(string:"Last Name",
//                                                               attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
//        signupPassword.attributedPlaceholder = NSAttributedString(string:"Password",
//                                                               attributes: [NSAttributedString.Key.foregroundColor: UIColor.black])
    }
    override func viewDidDisappear(_ animated: Bool) {
        defaultValues()
    }
    //MARK:- Helper Methods
    //function that fetch User Data
    func fetchDataBase(){
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let context = appDelegate.persistentContainer.viewContext
            //employee data
            let frequest = NSFetchRequest<NSFetchRequestResult>.init(entityName: "User")
            do {
                let userResult = try context.fetch(frequest)
                print(userResult)
                for obj in userResult {
                    if let obj = obj as? User {
                        print(obj.email)
                        print(obj.firstname)
                        print(obj.lastname)
                        print(obj.password)
                    }
                }
            }catch {
                print("Not able to fetch")
            }
            saveChanges()
        }
    }
    // function that Saves any changes in the context
    func saveChanges() {
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let context = appDelegate.persistentContainer.viewContext
        do {
            if context.hasChanges {
                try context.save()
            }
        } catch let error as NSError {
            print("Error \(error.description)")
        }
    }
    // function to set default value of labels
    func defaultValues() {
        signupEmail.text = ""
        signupFirstName.text = ""
        signupLastName.text = ""
        signupPassword.text = ""
        
    }
    //Email Validation
    func isValidEmail(testStr:String) -> Bool {
        
        print("validate emilId: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        return result
    }
    //Password Validation
    func isValidPassword(testPwd:String)->Bool {
        
        let passwordRegEx = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{6,12}$"
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", passwordRegEx)
        let result = passwordTest.evaluate(with: testPwd)
        return result
    }
    //MARK:- IBActions
    @IBAction func tapSignupWithEmail(_ sender: Any) {
       
        guard let checkEmail = signupEmail.text else {return}
        guard let checkPassword = signupPassword.text else{return}
        
        if isValidEmail(testStr: checkEmail)==true && signupFirstName.text != "" && signupLastName.text != "" && isValidPassword(testPwd: checkPassword)==true {
            
            if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
                let context = appDelegate.persistentContainer.viewContext
                // Saving USER data to database
                let userEntity = NSEntityDescription.entity(forEntityName: "User", in: context)
                let user = NSManagedObject(entity: userEntity!, insertInto: context)
                user.setValue(signupEmail.text, forKeyPath: "email")
                user.setValue(signupFirstName.text, forKeyPath: "firstname")
                user.setValue(signupLastName.text, forKeyPath: "lastname")
                user.setValue(signupPassword.text, forKeyPath: "password")
               }
            saveChanges()
            fetchDataBase()
            defaultValues()
            print("Data saved successfully")
            performSegue(withIdentifier: "LoginVC", sender: self)
        }
         else if isValidEmail(testStr: checkEmail)==false{
            let alert = UIAlertController(title: "Invalid Email", message:"" , preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        else if signupFirstName.text == "" {
            let alert = UIAlertController(title: "First Name Empty", message:"" , preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        else if signupLastName.text == "" {
            let alert = UIAlertController(title: "Last Name Empty", message:"" , preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
        else if isValidPassword(testPwd: checkPassword)==false{
            let alert = UIAlertController(title: "Invalid Password", message:"Minimum 6 and Maximum 12 characters, atleast 1 Uppercase Alphabet, 1 Lowercase Alphabet, 1 Number and No symbols allowed. " , preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
            self.present(alert, animated: true)
        }
    }
    @IBAction func tapBackToHome(_ sender: Any) {
        defaultValues()
        self.dismiss(animated: true, completion: nil)
    }
}

