//
//  DisplayVC.swift
//  FormDemo
//
//  Created by Suraj Prasad on 06/04/19.
//  Copyright © 2019 Suraj Prasad. All rights reserved.
//

import UIKit
import WebKit
class DisplayVC: UIViewController,WKNavigationDelegate {
    //MARK:- IBOutlets
    @IBOutlet weak var displayFirstName: UILabel!
    //MARK:- Global Variables
    var getFirstName:String?
    @IBOutlet weak var myWebView: WKWebView!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    //MARK:- Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        myWebView.navigationDelegate=self
        guard let url = URL(string: "https://snatchbot.me/webchat/?botID=52094&appID=mJCR0da19LEgadtde6y0") else { return }
        let requestObj = URLRequest(url: url as URL) 
        myWebView.load(requestObj)
        
        // Do any additional setup after loading the view.
        guard let setFirstName = getFirstName else{ return }
        displayFirstName.text = setFirstName
            activityIndicator.startAnimating()
            activityIndicator.alpha = 1
            
        }
    //MARK:- IBActions
    @IBAction func tapLogout(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    //MARK:- WKNavigation Delegate Methods
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!){
        activityIndicator.alpha = 0.1
        activityIndicator.stopAnimating()
        print("did commit working")
    }
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!){
        activityIndicator.alpha=0.0
        activityIndicator.stopAnimating()
        activityIndicator.isHidden=true
        print("did finish working")
    }
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        let alert = UIAlertController(title: "Alert", message:"Error 404. Go back and Try Again" , preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true)
        print("Error 404. Go back and Try Again")
    }
}
