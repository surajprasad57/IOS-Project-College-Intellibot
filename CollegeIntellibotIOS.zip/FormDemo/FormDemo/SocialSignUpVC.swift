//
//  SocialSignUpVC.swift
//  FormDemo
//
//  Created by Suraj Prasad on 05/04/19.
//  Copyright © 2019 Suraj Prasad. All rights reserved.
//

import UIKit
import GoogleSignIn
import FBSDKLoginKit
import FBSDKCoreKit

class SocialSignUpVC: UIViewController,GIDSignInUIDelegate,GIDSignInDelegate {
    //MARK:- Global Variables
    var firstName = ""
    var lastName = ""
    var email = ""
    var isFBSignUp = false
    var isGoogleSignUp = false
    var isEmailSignUp = false
    var fbFirstName = ""
    var fbLastName = ""
    var fbEmail = ""
    //MARK:- Life Cycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
          GIDSignIn.sharedInstance().delegate = self
          GIDSignIn.sharedInstance().uiDelegate = self
    }
    override func viewDidAppear(_ animated: Bool) {
         isFBSignUp = false
         isGoogleSignUp = false
         isEmailSignUp = false
    }
    //MARK- User Defined Methods
    //method to get fb user data
    func getFBUserData(){

        if((FBSDKAccessToken.current()) != nil){
            FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, name, first_name, last_name, picture.type(large), email"]).start(completionHandler: { (connection, result, error) -> Void in
                if (error == nil) {
                    //everything works print the user data
                    if let resultf = result as? Dictionary<String,Any> {
                        print(resultf)
                        self.fbEmail = (resultf["email"] as? String) ?? "defaultEmail@gmail.com"
                        self.fbFirstName = (resultf["first_name"] as? String) ?? "N/A"
                        self.fbLastName = (resultf["last_name"] as? String) ?? "N/A"
                        print("email==== \(resultf["email"] as? String)")
                        print("first_name==== \(resultf["first_name"] as? String)")
                        print("last_name==== \(resultf["last_name"] as? String)")
                         self.moveToSignupPage()
                    }
                }
            })
        }
    }
    //move to sign up page on fb login
    func moveToSignupPage() {
        self.isFBSignUp = true
        performSegue(withIdentifier:"EmailSignUpVC", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? EmailSignUpVC {
            if isFBSignUp == true {
                vc.getEmail = self.fbEmail
                vc.getFirstName = self.fbFirstName
                vc.getLastName = self.fbLastName
                print("fb vc Mail -- \(vc.getEmail)")
                print(self.fbFirstName)
                print(vc.getFirstName)
                isFBSignUp = false
            }
            else if isGoogleSignUp == true {
                vc.getEmail = self.email
                vc.getFirstName = self.firstName
                vc.getLastName = self.lastName
                print("google vc Mail -- \(vc.getEmail)")
                isGoogleSignUp = false
            }
            else if isEmailSignUp == true{
                vc.getEmail = ""
                vc.getFirstName = ""
                vc.getLastName = ""
                print("email vc Mail -- \(vc.getEmail)")
                print("email sign up")
                
                isEmailSignUp = false
            }
        }
    }
    //MARK:- Delegate Method
    //for google Sign in
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        self.email = user.profile.email
        self.firstName = user.profile.givenName
        self.lastName = user.profile.familyName
        self.isGoogleSignUp = true
        performSegue(withIdentifier:"EmailSignUpVC", sender: self)
    }
    //MARK:- IBActions
    @IBAction func tapEmail(_ sender: Any) {
        isEmailSignUp = true
         performSegue(withIdentifier:"EmailSignUpVC", sender: self)
    }
    @IBAction func tapGoogle(_ sender: Any) {
        GIDSignIn.sharedInstance()?.signIn()
    }
    
    @IBAction func tapFacebook(_ sender: Any) {
        let fbLoginManager : FBSDKLoginManager = FBSDKLoginManager()
     fbLoginManager.logIn(withReadPermissions: ["email"], from: self) { (result, error) -> Void in
            if (error == nil){
                let fbloginresult : FBSDKLoginManagerLoginResult = result!
                // if user cancel the login
                if (result?.isCancelled)!{
                    return
                }
                if(fbloginresult.grantedPermissions.contains("email"))
                {
                    self.getFBUserData()
                }
            }
        }
    }
}

